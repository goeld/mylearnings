package com.mycompany.mock.exchangerate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MockExchangeRateDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
