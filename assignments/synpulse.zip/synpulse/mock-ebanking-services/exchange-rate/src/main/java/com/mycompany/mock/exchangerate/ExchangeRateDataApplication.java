package com.mycompany.mock.exchangerate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExchangeRateDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExchangeRateDataApplication.class, args);
	}

}
