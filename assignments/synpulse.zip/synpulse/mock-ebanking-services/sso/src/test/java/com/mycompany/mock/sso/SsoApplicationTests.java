package com.mycompany.mock.sso;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SsoApplicationTests {

	@Test
	void contextLoads() {
	}

}
