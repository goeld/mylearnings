# mock-ebanking-services
Mock services for Account, Customer, SSO, Transaction Service and Exchange Rate 


Refer to eBanking README.md for details on assignment.
