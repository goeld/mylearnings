./bin/bash

docker build -t ebank-api .