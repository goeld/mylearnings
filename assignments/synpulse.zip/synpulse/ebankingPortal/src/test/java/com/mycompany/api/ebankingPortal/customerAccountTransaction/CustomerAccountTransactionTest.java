package com.mycompany.api.ebankingPortal.customerAccountTransaction;

public class CustomerAccountTransactionTest {
}
