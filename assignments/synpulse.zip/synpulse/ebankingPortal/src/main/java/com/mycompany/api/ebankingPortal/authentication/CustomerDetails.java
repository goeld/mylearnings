package com.mycompany.api.ebankingPortal.authentication;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class CustomerDetails {

    private String customerId;

    //Ommiting other details

}
