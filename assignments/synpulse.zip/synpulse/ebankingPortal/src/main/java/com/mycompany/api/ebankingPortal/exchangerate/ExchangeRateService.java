package com.mycompany.api.ebankingPortal.exchangerate;

import java.util.Map;

public interface ExchangeRateService {

    Map<String, Double> getAllExhangeRates();
}
