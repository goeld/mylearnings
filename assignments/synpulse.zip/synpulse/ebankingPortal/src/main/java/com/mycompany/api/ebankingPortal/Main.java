import java.util.*;

class Main {
    public static void main(String[] args) {
        System.out.println("Hello, world!");
    }

    // Entities - Couple of entities
    // Entity -> LocationQuanitty
    // Entity -> Item (Enum)
    // Map <Enum,List<LocationQuanitty>>


    public static Map<String, List<Main.LocationQuanity>> parseJson(String argv1) {


        Map<String, List<LocationQuanity>> productMap = new HashMap<>();
        List<LocationQuanity> list = new ArrayList<>();
        list.add (new LocationQuanity(1001, 100));
        list.add (new LocationQuanity(1020, 15));
        list.add (new LocationQuanity(1001, 25));

        // Add First product

        productMap.put(Item.SKU_A.getName(), list);
        // Add another products


        return   productMap;

    }

    public static Integer findProduct(Map<String, List<Main.LocationQuanity>> productMap, String product){

        boolean hasProduct = false;
        for (Item name : Item.values()){
            if (name.equalsIgnoreCase(product)){
                hasProduct = true;
                break;
            }
        }

        if (!hasProduct){
            // throw new Exception("prod not found");
            return null;
        }


        int totalItems = 0 ;
        List<Main.LocationQuanity> locQuantity = productMap.get(product);
        if (locQuantity == null) {
            return totalItems;
        }



        for(LocationQuanity lq : locQuantity) {

            if (lq.location == 1001 ) {
                totalItems += lq.quantity;
            }
        }


        return totalItems;



    }




    static class LocationQuanity{
        public Integer location;
        public Integer quantity;
        LocationQuanity(Integer location, Integer quantity){
            this.location = location;
            this.quantity = quantity;
        }



    }

    enum Item {
        SKU_A("SKU-A"),
        SKU_B("SKU-B"),
        SKU_C("SKU-C");

        String name;
        Item(String name){

            this.name = name;

        }

        String getName(){
            return name;
        }

    }


}