package com.online.pajak.tax_app.beans;

public class Slab {

	private String name;
	private Long minIncome;
	private Long maxIncome;
	private int taxRatePercentage;

	public Slab() {
	}

	public Slab(String name, Long minIncome, Long maxIncome, int taxRatePercentage) {
		this.name = name;
		this.minIncome = minIncome;
		this.maxIncome = maxIncome;
		this.taxRatePercentage = taxRatePercentage;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getMinIncome() {
		return minIncome;
	}

	public void setMinIncome(Long minIncome) {
		this.minIncome = minIncome;
	}

	public Long getMaxIncome() {
		return maxIncome;
	}

	public void setMaxIncome(Long maxIncome) {
		this.maxIncome = maxIncome;
	}

	public int getTaxRatePercentage() {
		return taxRatePercentage;
	}

	public void setTaxRatePercentage(int taxRatePercentage) {
		this.taxRatePercentage = taxRatePercentage;
	}

}
