package com.online.pajak.tax_app.beans;

import java.util.List;

public class TaxConfiguration {

	private String currency;
	private Income income;
	private List<Relief> reliefs;

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public Income getIncome() {
		return income;
	}

	public void setIncome(Income income) {
		this.income = income;
	}

	public List<Relief> getReliefs() {
		return reliefs;
	}

	public void setReliefs(List<Relief> reliefs) {
		this.reliefs = reliefs;
	}

}
