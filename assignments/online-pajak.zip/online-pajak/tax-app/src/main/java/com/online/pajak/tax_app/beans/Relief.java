package com.online.pajak.tax_app.beans;

public class Relief {
	private String code;
	private String name;
	private Long amount;

	public Relief() {
	}

	public Relief(String code, String name, Long amount) {
		this.code = code;
		this.name = name;
		this.amount = amount;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getAmount() {
		return amount;
	}

	public void setAmount(Long amount) {
		this.amount = amount;
	}

}
