package com.online.pajak.tax_app.service;

import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import com.online.pajak.tax_app.beans.Relief;
import com.online.pajak.tax_app.beans.Slab;

public class TaxService {

	private List<Relief> reliefs;
	private List<Slab> incomeSlabs;

	public TaxService(List<Slab> incomeSlabs, List<Relief> reliefs) {
		this.reliefs = reliefs;
		this.incomeSlabs = incomeSlabs;
	}

	public Set<String> getAllTaxCodes() {
		return reliefs.stream().map(relief -> relief.getCode()).distinct().collect(Collectors.toSet());
	}

	public Long calculateTax(final Long taxableIncome) {

		Double totalPayableTax = 0d;
		Long remainingIncome = taxableIncome;
		Long previousSlabMaxIncome = 0L;

		List<Slab> slabs = incomeSlabs.stream().sorted(Comparator.comparing(Slab::getMinIncome))
				.collect(Collectors.toList());

		for (Slab slab : slabs) {
			// System.out.println(" Slab Name : " + slab.getName());
			// System.out.println(" remainingIncome Before: " + remainingIncome);

			Long currentSlabTaxableIncome = 0L;
			if (slab.getMaxIncome() != null) {
				Long currentSlabMaxIncome = slab.getMaxIncome();
				currentSlabTaxableIncome = currentSlabMaxIncome - previousSlabMaxIncome;

				if (remainingIncome > currentSlabTaxableIncome) {
					totalPayableTax += currentSlabTaxableIncome * slab.getTaxRatePercentage() * 0.01;
				} else {
					totalPayableTax += remainingIncome * slab.getTaxRatePercentage() * 0.01;
				}

			} else {
				totalPayableTax += remainingIncome * slab.getTaxRatePercentage() * 0.01;
				currentSlabTaxableIncome = remainingIncome;
			}

			remainingIncome -= currentSlabTaxableIncome;
			previousSlabMaxIncome = slab.getMaxIncome();

			// System.out.println(" remainingIncome : " + remainingIncome);
			// System.out.println(" totalPayableTax : " + totalPayableTax);
			// System.out.println("");
			if (remainingIncome <= 0) {
				break;
			}
		}

		return totalPayableTax.longValue();
	}

	public Long getTaxableIncome(final Long monthlyIncome, final String applicatbleReliefCode) {

		return monthlyIncome * 12 - getReliefAmount(applicatbleReliefCode);
	}

	public Long getReliefAmount(final String applicatbleReliefCode) {

		Relief taxRelief = this.reliefs.stream()
				.filter(relief -> applicatbleReliefCode.equalsIgnoreCase(relief.getCode())).collect(Collectors.toList())
				.get(0);

		// System.out.println("Relief Amount = " + taxRelief.getAmount());

		return taxRelief.getAmount();

	}

}
