package com.online.pajak.tax_app;

import java.io.File;
import java.io.IOException;
import java.util.Set;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.online.pajak.tax_app.beans.TaxConfiguration;
import com.online.pajak.tax_app.service.TaxService;

public class App {

	public static void main(String[] args) throws JsonParseException, JsonMappingException, IOException {
		App application = new App();
		TaxConfiguration configuration = application.initializeTaxInfo();
		UserInput ui = new UserInput();

		TaxService service = new TaxService(configuration.getIncome().getSlabs(), configuration.getReliefs());
		Set<String> allReliefCodes = service.getAllTaxCodes();

		Long monthlyIncome = null;
		String applicatbleReliefCode = null;

		if (args != null && args.length == 2) { // If user input is from command line
			monthlyIncome = Long.parseLong(args[0]);
			applicatbleReliefCode = args[1];

		} else { // if the user input is not from command line
			monthlyIncome = ui.getAnnualIncome();

			configuration.getReliefs().forEach(relief -> System.out
					.println("- " + relief.getCode() + " - " + relief.getName() + " - " + relief.getAmount()));

			applicatbleReliefCode = ui.getTaxReliefCode(allReliefCodes);
		}

		// Calculate Taxable Income from monthly income and reliefs
		Long taxableIncome = service.getTaxableIncome(monthlyIncome, applicatbleReliefCode);

		// Calculate Tax
		Long taxAmount = service.calculateTax(taxableIncome);

		// Print Results
		System.out.println("Income Monthly = " + monthlyIncome);
		System.out.println("Taxable Income = " + taxableIncome);
		System.out.println("taxAmount      = " + taxAmount);
	}

	public TaxConfiguration initializeTaxInfo() throws JsonParseException, JsonMappingException, IOException {
		TaxConfiguration tax = null;

		ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("tax_calculation_configuration.yml").getFile());
		
		tax = mapper.readValue(file, TaxConfiguration.class);
		System.out.println(tax);

		return tax;
	}
}
