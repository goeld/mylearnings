package com.online.pajak.tax_app.beans;

import java.util.List;

public class Income {

	private int slabCount;
	private List<Slab> slabs;

	public int getSlabCount() {
		return slabCount;
	}

	public void setSlabCount(int slabCount) {
		this.slabCount = slabCount;
	}

	public List<Slab> getSlabs() {
		return slabs;
	}

	public void setSlabs(List<Slab> slabs) {
		this.slabs = slabs;
	}

}
