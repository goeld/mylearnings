package com.online.pajak.tax_app;

import java.util.Scanner;
import java.util.Set;

public class UserInput {

	private Scanner scanner = new Scanner(System.in);

	public Long getAnnualIncome() {

		System.out.println("\nEnter your income ");

		String inputIncome = null;
		boolean isValidCode = false;

		Long income = -1L;
		do {
			inputIncome = scanner.nextLine();
			income = Long.parseLong(inputIncome);
			if (income > 0) {
				isValidCode = true;
				break;
			}
			if (!isValidCode) {
				System.out.println("\nInvalid Income, please input again ");
			}
		} while (!isValidCode);

		return income;

	}

	public String getTaxReliefCode(Set<String> validCodes) {

		System.out.println("\nEnter your Tax Relief Code ");
		String input = null;
		boolean isValidCode = false;

		do {
			input = scanner.nextLine();
			for (String validCode : validCodes) {
				if (validCode.equalsIgnoreCase(input)) {
					isValidCode = true;
					break;
				}
			}
			if (!isValidCode) {
				System.out.println("\nInvalid Tax Relief Code, please input again ");
			}
		} while (!isValidCode);

		return input;
	}

}
