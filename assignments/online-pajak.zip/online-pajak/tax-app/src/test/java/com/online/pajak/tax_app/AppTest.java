package com.online.pajak.tax_app;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.io.IOException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.online.pajak.tax_app.beans.Income;
import com.online.pajak.tax_app.beans.TaxConfiguration;

@RunWith(JUnit4.class)
public class AppTest {

	private App app;

	@Test
	public void testInitializeTaxInfo() throws JsonParseException, JsonMappingException, IOException {
		app = new App();
		TaxConfiguration config = app.initializeTaxInfo();

		assertEquals("IDR", config.getCurrency());

		// Assert Incomes
		Income income = config.getIncome();
		assertNotNull(income);
		assertEquals(4, income.getSlabCount());

		assertNotNull(income.getSlabs());
		assertEquals(4, income.getSlabs().size());

		assertEquals("5 Percent", income.getSlabs().get(0).getName());
		assertEquals(new Long(0), income.getSlabs().get(0).getMinIncome());
		assertEquals(new Long(50000000), income.getSlabs().get(0).getMaxIncome());
		assertEquals(5, income.getSlabs().get(0).getTaxRatePercentage());

		assertEquals("15 Percent", income.getSlabs().get(1).getName());
		assertEquals(new Long(50000000), income.getSlabs().get(1).getMinIncome());
		assertEquals(new Long(250000000), income.getSlabs().get(1).getMaxIncome());
		assertEquals(15, income.getSlabs().get(1).getTaxRatePercentage());

		assertEquals("25 Percent", income.getSlabs().get(2).getName());
		assertEquals(new Long(250000000), income.getSlabs().get(2).getMinIncome());
		assertEquals(new Long(500000000), income.getSlabs().get(2).getMaxIncome());
		assertEquals(25, income.getSlabs().get(2).getTaxRatePercentage());

		assertEquals("30 Percent", income.getSlabs().get(3).getName());
		assertEquals(new Long(500000000), income.getSlabs().get(3).getMinIncome());
		assertNull(income.getSlabs().get(3).getMaxIncome());
		assertEquals(30, income.getSlabs().get(3).getTaxRatePercentage());

		// Assert Reliefs
		assertNotNull(config.getReliefs());
		assertEquals(5, config.getReliefs().size());

		assertEquals("TK0", config.getReliefs().get(0).getCode());
		assertEquals("Single", config.getReliefs().get(0).getName());
		assertEquals(new Long(54000000), config.getReliefs().get(0).getAmount());

		assertEquals("K0", config.getReliefs().get(1).getCode());
		assertEquals("Married with no dependant", config.getReliefs().get(1).getName());
		assertEquals(new Long(58500000), config.getReliefs().get(1).getAmount());

		assertEquals("K1", config.getReliefs().get(2).getCode());
		assertEquals("Married with 1 dependant", config.getReliefs().get(2).getName());
		assertEquals(new Long(63000000), config.getReliefs().get(2).getAmount());

		assertEquals("K2", config.getReliefs().get(3).getCode());
		assertEquals("Married with 2 dependant", config.getReliefs().get(3).getName());
		assertEquals(new Long(67000000), config.getReliefs().get(3).getAmount());

		assertEquals("K3", config.getReliefs().get(4).getCode());
		assertEquals("Married with 3 dependant", config.getReliefs().get(4).getName());
		assertEquals(new Long(72000000), config.getReliefs().get(4).getAmount());

	}

}
