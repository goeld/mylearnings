package com.online.pajak.tax_app.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import com.online.pajak.tax_app.beans.Relief;
import com.online.pajak.tax_app.beans.Slab;

@RunWith(JUnit4.class)
public class TaxServiceTests {

	private TaxService taxService;

	@Before
	public void setup() {
		List<Relief> reliefs = initializeReliefs();
		List<Slab> incomeSlabs = initializeIncomeSlabs();
		taxService = new TaxService(incomeSlabs, reliefs);

	}

	private List<Relief> initializeReliefs() {
		Relief tk0 = new Relief("TK0", "Single", 54000000L);
		Relief k0 = new Relief("K0", "Married with no dependant", 58500000L);
		Relief k1 = new Relief("K1", "Married with 1 dependant", 63000000L);
		Relief k2 = new Relief("K2", "Married with 2 dependant", 67500000L);
		Relief k3 = new Relief("K3", "Married with 3 dependant", 72000000L);

		List<Relief> reliefs = new ArrayList<>();
		reliefs.add(tk0);
		reliefs.add(k0);
		reliefs.add(k1);
		reliefs.add(k2);
		reliefs.add(k3);
		return reliefs;
	}

	private List<Slab> initializeIncomeSlabs() {
		Slab slab1 = new Slab("5 Percent", 0L, 50000000L, 5);
		Slab slab2 = new Slab("15 Percent", 50000000L, 250000000L, 15);
		Slab slab3 = new Slab("25 Percent", 250000000L, 500000000L, 25);
		Slab slab4 = new Slab("30 Percent", 500000000L, null, 30);

		List<Slab> incomeSlabs = new ArrayList<>();
		incomeSlabs.add(slab1);
		incomeSlabs.add(slab2);
		incomeSlabs.add(slab3);
		incomeSlabs.add(slab4);
		return incomeSlabs;
	}

	@Test
	public void testGetAllTaxCodes_Success() {

		Set<String> expected = new HashSet<>(Arrays.asList("TK0", "K0", "K1", "K2", "K3"));

		Set<String> actual = taxService.getAllTaxCodes();

		Assert.assertEquals(expected.size(), actual.size());
		Assert.assertEquals(expected, actual);

	}

	@Test
	public void testGetAllTaxCodes_CountMismatch() {

		Set<String> expected = new HashSet<>(Arrays.asList("TK0", "K0", "K1", "K2", "K3", "K5"));

		Set<String> actual = taxService.getAllTaxCodes();

		Assert.assertNotEquals(expected.size(), actual.size());
		Assert.assertNotEquals(expected, actual);

	}

	@Test
	public void testGetAllTaxCodes_ContentsMismatch() {

		Set<String> expected = new HashSet<>(Arrays.asList("TK0", "K0", "K1", "K2", "K4"));

		Set<String> actual = taxService.getAllTaxCodes();

		Assert.assertEquals(expected.size(), actual.size());
		Assert.assertNotEquals(expected, actual);

	}

	@Test
	public void testGetReliefAmount_Matches() {

		Long expected = 54000000L;
		Assert.assertEquals(expected, taxService.getReliefAmount("TK0"));

	}

	@Test
	public void testGetReliefAmount_MisMatch() {

		Long expected = 58500000L;
		Assert.assertNotEquals(expected, taxService.getReliefAmount("TK0"));

	}

	@Test
	public void testGetTaxableIncome_Match() {
		Long monthlySalary = 6500000L;
		String taxCode = "K1";
		Long expected = 15000000L;
		Assert.assertEquals(expected, taxService.getTaxableIncome(monthlySalary, taxCode));
	}

	@Test
	public void testCalculateTax_WithMinimumIncomeSlab() {
		Long taxableIncome = 25000000L;
		Double tax = taxableIncome * 5 * 0.01;
		Long expected = tax.longValue();
		Assert.assertEquals(expected, taxService.calculateTax(taxableIncome));
	}

	@Test
	public void testCalculateTax_WithSecondIncomeSlab() {
		Long taxableIncome = 55000000L;

		Double tax = 50000000 * .05 + 5000000 * .15;
		Long expected = tax.longValue();
		Assert.assertEquals(expected, taxService.calculateTax(taxableIncome));
	}

	@Test
	public void testCalculateTax_WithThirdIncomeSlab() {
		Long taxableIncome = 255000000L;

		Double tax = 50000000 * .05 + 200000000 * .15 + 5000000 * .25;
		Long expected = tax.longValue();
		Assert.assertEquals(expected, taxService.calculateTax(taxableIncome));
	}

	@Test
	public void testCalculateTax_WithLastIncomeSlab() {
		Long taxableIncome = 550000000L;

		Double tax = 50000000 * .05 + 200000000 * .15 + 250000000 * .25 + 50000000 * .3;
		Long expected = tax.longValue();
		Assert.assertEquals(expected, taxService.calculateTax(taxableIncome));
	}

}
