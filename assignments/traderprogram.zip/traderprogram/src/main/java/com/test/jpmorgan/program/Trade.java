package com.test.jpmorgan.program;

import com.test.jpmorgan.entity.Direction;
import com.test.jpmorgan.entity.Operation;
import com.test.jpmorgan.entity.Position;
import com.test.jpmorgan.entity.TradeEvent;

import java.util.*;

/**
 * Created by aadi on 10/8/15.
 */
public class Trade {

    private static Map<String, List<TradeEvent>> tradeStreamMap;
    private static Map<String, Position> positionMap = new HashMap<String, Position>();

    public static synchronized Map<String, List<TradeEvent>> getTradeStreamMap() {

        if (tradeStreamMap == null) {
            tradeStreamMap = new HashMap<String, List<TradeEvent>>();
        }
        return tradeStreamMap;
    }

    public static synchronized Map<String, Position> getPositionMap() {

        if (positionMap == null) {
            positionMap = new HashMap<String, Position>();
        }
        return positionMap;
    }

    public Map<String, List<TradeEvent>> processEventStream(TradeEvent event) {
        if (event == null) {
            // Invlaid event throw exception.
            return getTradeStreamMap();
        }

        if (event.getTradeId() == null || event.getSecurityId() == null) {
            return getTradeStreamMap();
        }
        String key = event.getTradeId() + "~" + event.getSecurityId();

        List<TradeEvent> tradeEvents = getTradeStreamMap().get(key);

        if (tradeEvents == null) {
            List<TradeEvent> events = new ArrayList<TradeEvent>();
            events.add(event);
            getTradeStreamMap().put(key, events);
        } else {
            boolean existing = false;
            for (Iterator<TradeEvent> eventIterator = tradeEvents.iterator(); eventIterator.hasNext(); ) {
                TradeEvent e = eventIterator.next();
                if (e.getTradeId().equals(event.getTradeId())) {
                    if(event.getTradeVersion() > e.getTradeVersion()){
                        eventIterator.remove();
                        existing = true;
                        break;
                    }
                } else {
                    tradeEvents.add(event);
                }


            }
            if(existing){
                tradeEvents.add(event);
            }
        }

        return getTradeStreamMap();
    }


    public void tradeEvent(Set<String> keys) {

        for(String key : keys){


        List<TradeEvent> tradeEvents = getTradeStreamMap().get(key);
        Position position = getPositionMap().get(key);
        for (TradeEvent currentEvent : tradeEvents) {

            Direction tradeDirection = currentEvent.getDirection();
            Operation tradeOperation = currentEvent.getOperation();

            System.out.print("TD ::" + tradeDirection.name());
            System.out.print("TO ::" + tradeOperation.name());

            if (position == null) {
                position = new Position(currentEvent.getAccountNo(), currentEvent.getSecurityId());
                getPositionMap().put(key, position);
            }

            Integer quantity = position.getQuantity();
            if ((tradeDirection == Direction.BUY && (tradeOperation == Operation.NEW || tradeOperation == Operation.AMEND))
                    || (tradeDirection == Direction.SELL && tradeOperation == Operation.CANCEL)) {
                System.out.print("Increment");
                quantity += currentEvent.getQuantity();

            } else if ((tradeDirection == Direction.SELL && (tradeOperation == Operation.NEW || tradeOperation == Operation.AMEND))
                    || (tradeDirection == Direction.BUY && tradeOperation == Operation.CANCEL)) {
                System.out.print("Decrement");
                quantity -= currentEvent.getQuantity();

            }

            position.setQuantity(quantity);
            List<Integer> tradeIds = position.getTradeIds();
            if (tradeIds == null) {
                tradeIds = new ArrayList<Integer>();
                position.setTradeIds(tradeIds);
            }
            tradeIds.add(currentEvent.getTradeId());
        }

        }

    }


    public Position getPosition(String accountNo) {
        return positionMap.get(accountNo);
    }

}
