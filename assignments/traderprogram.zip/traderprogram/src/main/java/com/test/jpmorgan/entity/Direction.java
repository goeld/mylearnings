package com.test.jpmorgan.entity;

/**
 * Created by aadi on 10/8/15.
 */
public enum Direction {

    BUY,
    SELL


}
