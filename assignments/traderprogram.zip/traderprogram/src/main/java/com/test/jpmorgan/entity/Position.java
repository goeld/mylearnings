package com.test.jpmorgan.entity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by aadi on 10/8/15.
 */
public class Position {

    private String accountNo;
    private String instruments;
    private Integer quantity;
    private List<Integer> tradeIds;

    public Position(String accountNo, String instruments) {
        this.accountNo = accountNo;
        this.instruments = instruments;
        tradeIds = new ArrayList<Integer>();
        quantity = 0 ;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public List<Integer> getTradeIds() {
        return tradeIds;
    }

    public void setTradeIds(List<Integer> tradeIds) {
        this.tradeIds = tradeIds;
    }

    @Override
    public String toString() {

        return this.accountNo.toString() + this.instruments + this.quantity + this.getTradeIds().toString();
    }
}
