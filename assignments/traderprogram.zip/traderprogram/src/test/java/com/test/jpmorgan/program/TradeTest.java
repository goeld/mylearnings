package com.test.jpmorgan.program;

import com.test.jpmorgan.entity.Direction;
import com.test.jpmorgan.entity.Operation;
import com.test.jpmorgan.entity.Position;
import com.test.jpmorgan.entity.TradeEvent;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.*;

/**
 * Created by aadi on 10/8/15.
 */
public class TradeTest {

    List<TradeEvent> allTradingEvents = new ArrayList<TradeEvent>();

    private static Map<String, Position> positionMap;

    @Before
    public void setUp() throws Exception {
        allTradingEvents = new ArrayList<TradeEvent>();
    }

    @Test
    public void testJunit() {
        System.out.println("Test run");
    }

    @Test
    public void testTradeFprAcc1234() {

        allTradingEvents.addAll(eventForAcc1234());
        Trade trade = new Trade();
        Set<String> keys = new HashSet<String>();

        for (TradeEvent event : allTradingEvents) {
            trade.processEventStream(event);
            keys.add((event.getTradeId() + "~" + event.getSecurityId()));
        }

        trade.tradeEvent(keys);

        Position position = trade.getPosition("1234~XYZ");
        System.out.println("Position is " + position);
    }

    @Test
    public void testTradeFprAcc2345() {

        allTradingEvents.addAll(eventForAcc2345());
        Trade trade = new Trade();
        Set<String> keys = new HashSet<String>();
        for (TradeEvent event : allTradingEvents) {
            trade.processEventStream(event);
            keys.add((event.getTradeId() + "~" + event.getSecurityId()));
        }

        trade.tradeEvent(keys);
        Position position = trade.getPosition("5678~QED");
        Assert.assertEquals(position.getQuantity().intValue(), 200);
        Position position2 = trade.getPosition("7897~QED");
        Assert.assertEquals(position2.getQuantity().intValue(), 0);
        System.out.println("Position is " + position);
    }

    @Test
    public void testTradeFprAcc3456() {
        allTradingEvents.addAll(eventForAcc3456());
        Trade trade = new Trade();
        Set<String> keys = new HashSet<String>();
        for (TradeEvent event : allTradingEvents) {
            trade.processEventStream(event);
            keys.add((event.getTradeId() + "~" + event.getSecurityId()));
        }

        trade.tradeEvent(keys);
        Position position = trade.getPosition("2233~RET");
        Assert.assertEquals(position.getQuantity().intValue(), 0);
    }

    private List<TradeEvent> eventForAcc1234() {
        List<TradeEvent> events = new ArrayList<TradeEvent>();
        TradeEvent event1 = new TradeEvent();
        event1.setTradeId(1234);
        event1.setTradeVersion(1);
        event1.setSecurityId("XYZ");
        event1.setQuantity(100);
        event1.setDirection(Direction.BUY);
        event1.setAccountNo("ACC-1234");
        event1.setOperation(Operation.NEW);
        events.add(event1);


        TradeEvent event2 = new TradeEvent();
        event2.setTradeId(1234);
        event2.setTradeVersion(2);
        event2.setSecurityId("XYZ");
        event2.setQuantity(150);
        event2.setDirection(Direction.BUY);
        event2.setAccountNo("ACC-1234");
        event2.setOperation(Operation.AMEND);
        events.add(event2);

        return events;


    }

    private List<TradeEvent> eventForAcc2345() {
        List<TradeEvent> events = new ArrayList<TradeEvent>();
        TradeEvent event2 = new TradeEvent();
        event2.setTradeId(5678);
        event2.setTradeVersion(1);
        event2.setSecurityId("QED");
        event2.setQuantity(200);
        event2.setDirection(Direction.BUY);
        event2.setAccountNo("ACC-2345");
        event2.setOperation(Operation.NEW);
        events.add(event2);

        TradeEvent event1 = new TradeEvent();
        event1.setTradeId(7897);
        event1.setTradeVersion(2);
        event1.setSecurityId("QED");
        event1.setQuantity(0);
        event1.setDirection(Direction.BUY);
        event1.setAccountNo("ACC-2345");
        event1.setOperation(Operation.CANCEL);
        events.add(event1);
        return events;
    }


    private List<TradeEvent> eventForAcc3456(){
        List<TradeEvent> events = new ArrayList<TradeEvent>();
        TradeEvent event1 = new TradeEvent();
        event1.setTradeId(2233);
        event1.setTradeVersion(1);
        event1.setSecurityId("RET");
        event1.setQuantity(100);
        event1.setDirection(Direction.SELL);
        event1.setAccountNo("ACC-3456");
        event1.setOperation(Operation.NEW);
        events.add(event1);

        TradeEvent event2 = new TradeEvent();
        event2.setTradeId(2233);
        event2.setTradeVersion(2);
        event2.setSecurityId("RET");
        event2.setQuantity(400);
        event2.setDirection(Direction.SELL);
        event2.setAccountNo("ACC-3456");
        event2.setOperation(Operation.AMEND);
        events.add(event2);

        TradeEvent event3 = new TradeEvent();
        event3.setTradeId(2233);
        event3.setTradeVersion(3);
        event3.setSecurityId("RET");
        event3.setQuantity(0);
        event3.setDirection(Direction.SELL);
        event3.setAccountNo("ACC-3456");
        event3.setOperation(Operation.AMEND);
        events.add(event3);

        return events;
    }

//    TradeEvent event = new TradeEvent();
//    event.setTradeId();
//    event.setTradeVersion();
//    event.setSecurityId("");
//    event.setQuantity();
//    event.setDirection(Direction.);
//    event.setAccountNo("");
//    event.setOperation(Operation.);
//    events.add(event)


}
