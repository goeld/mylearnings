## System Requirement 
The program is developer using Java 11 version and is compiled for Java 8 version. You need to have following prerequisite installed:

1. Java SDK - 8 and Java home is set to class path.
2. Maven - 3+
3. (Optional) IDE of your choice. Program can be run from the command line also.

## Getting Ready

Download the zip file to a directory and run the following commands in terminal (make sure you are in same directory as program is downloaded).

```
$: unzip drawing-program.zip
$: cd drawing-program
$: mvn clean
$: mvn test
$: mvn install 
$: java -jar target/draw-1.0-SNAPSHOT.jar
```
