package com.cs.draw.domain;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

@RunWith(JUnit4.class)
public class CanvasTest {

    @Test
    public void testGetSetColor(){
        int height = 3;
        int width = 6;
        Canvas canvas = new Canvas(width, height);
        canvas.setColor(1, 1, 'p');

        assertEquals('p', canvas.getColor(1, 1));
    }

}
