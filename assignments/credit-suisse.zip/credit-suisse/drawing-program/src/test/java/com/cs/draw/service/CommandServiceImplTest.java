package com.cs.draw.service;

import com.cs.draw.domain.Command;
import com.cs.draw.exception.CommandException;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class CommandServiceImplTest {

    CommandServiceImpl commandService = new CommandServiceImpl();

    @Test
    public void testValidateParameter_DRAW_CANVAS() throws Exception {

        Command expected = Command.DRAW_CANVAS;
        String[] input = new String[]{"20", "4"};
        expected.setInputs(input);

        Command actual = commandService.validateParameters(Command.DRAW_CANVAS, new String[]{"C", "20", "4"});
        assertEquals(actual.getCommand(), expected.getCommand());
        assertEquals(actual.getInputs().length, expected.getInputs().length);
        assertEquals(actual.getInputs()[0], expected.getInputs()[0]);
        assertEquals(actual.getInputs()[1], expected.getInputs()[1]);
    }

    @Test(expected = CommandException.class)
    public void testValidateParameter_NonIntegerValue() throws Exception {
        commandService.validateParameters(Command.DRAW_CANVAS, new String[]{"C", "20", "x"});
    }

    @Test(expected = CommandException.class)
    public void testValidateParameter_IncorrectNoOfParameters() throws Exception {
        commandService.validateParameters(Command.DRAW_CANVAS, new String[]{"C", "20", ""});
    }

    @Test
    public void testValidateParameter_DRAW_LINE() throws Exception {

        Command expected = Command.DRAW_LINE;
        String[] input = new String[]{"1", "2", "6", "2"};
        expected.setInputs(input);

        Command actual = commandService.validateParameters(Command.DRAW_LINE, new String[]{"L", "1", "2", "6", "2"});
        assertEquals(actual.getCommand(), expected.getCommand());
        assertEquals(actual.getInputs().length, expected.getInputs().length);
        assertEquals(actual.getInputs()[0], expected.getInputs()[0]);
        assertEquals(actual.getInputs()[1], expected.getInputs()[1]);
        assertEquals(actual.getInputs()[2], expected.getInputs()[2]);
        assertEquals(actual.getInputs()[3], expected.getInputs()[3]);
    }

    @Test
    public void testValidateParameter_DRAW_RECTANGLE() throws Exception {

        Command expected = Command.DRAW_RECTANGLE;
        String[] input = new String[]{"14", "1", "18", "3"};
        expected.setInputs(input);

        Command actual = commandService.validateParameters(Command.DRAW_RECTANGLE, new String[]{"R", "14", "1", "18", "3"});
        assertEquals(actual.getCommand(), expected.getCommand());
        assertEquals(actual.getInputs().length, expected.getInputs().length);
        assertEquals(actual.getInputs()[0], expected.getInputs()[0]);
        assertEquals(actual.getInputs()[1], expected.getInputs()[1]);
        assertEquals(actual.getInputs()[2], expected.getInputs()[2]);
        assertEquals(actual.getInputs()[3], expected.getInputs()[3]);
    }


    @Test
    public void testValidateParameter_BUCKET_FILL() throws Exception {

        Command expected = Command.BUCKET_FILL;
        String[] input = new String[]{"20", "4"};
        expected.setInputs(input);

        Command actual = commandService.validateParameters(Command.BUCKET_FILL, new String[]{"B", "20", "4"});
        assertEquals(actual.getCommand(), expected.getCommand());
        assertEquals(actual.getInputs().length, expected.getInputs().length);
        assertEquals(actual.getInputs()[0], expected.getInputs()[0]);
        assertEquals(actual.getInputs()[1], expected.getInputs()[1]);
    }

    @Test
    public void testValidateParameter_QUIT() throws Exception {
        Command expected = Command.QUIT;
        Command actual = commandService.validateParameters(Command.QUIT, null);
        assertEquals(actual.getCommand(), expected.getCommand());
        assertNull(actual.getInputs());
    }

    @Test
    public void testValidateCommand() throws Exception {

        Command expected = Command.DRAW_RECTANGLE;
        expected.setInputs(new String[]{"14", "1", "18", "3"});
        Command actual = commandService.validateParameters(Command.DRAW_RECTANGLE, new String[]{"R", "14", "1", "18", "3"});
        assertEquals(actual.getCommand(), expected.getCommand());
        assertEquals(actual.getInputs().length, expected.getInputs().length);
        assertEquals(actual.getInputs()[0], expected.getInputs()[0]);
        assertEquals(actual.getInputs()[1], expected.getInputs()[1]);
        assertEquals(actual.getInputs()[2], expected.getInputs()[2]);
        assertEquals(actual.getInputs()[3], expected.getInputs()[3]);


    }


    @Test
    public void testGetCommand() throws Exception {
        Command expected = Command.DRAW_LINE;
        expected.setInputs(new String[]{"1", "2", "6", "2"});
        Command actual = commandService.getCommand("L 1 2 6 2");
        assertEquals(actual.getCommand(), expected.getCommand());
        assertEquals(actual.getInputs().length, expected.getInputs().length);
        assertEquals(actual.getInputs()[0], expected.getInputs()[0]);
        assertEquals(actual.getInputs()[1], expected.getInputs()[1]);
        assertEquals(actual.getInputs()[2], expected.getInputs()[2]);
        assertEquals(actual.getInputs()[3], expected.getInputs()[3]);
    }
}
