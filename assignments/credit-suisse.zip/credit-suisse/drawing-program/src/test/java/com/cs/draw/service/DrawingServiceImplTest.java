package com.cs.draw.service;

import com.cs.draw.domain.Command;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;


public class DrawingServiceImplTest {

    DrawingServiceImpl drawingService = new DrawingServiceImpl();
    CommandServiceImpl commandService = new CommandServiceImpl();

    @Before
    public void setUp() throws Exception {
        Command drawCanvas = commandService.validateParameters(Command.DRAW_CANVAS, new String[]{"C", "20", "4"});
        drawingService.runCommand(drawCanvas);
    }

    @Test
    public void testDrawLine() throws Exception {

        Command drawLine = commandService.validateParameters(Command.DRAW_LINE, new String[]{"L", "1", "2", "6", "2"});

        drawingService.drawline(drawLine, 1, 2, 6, 2);
        String actualCanvas = drawingService.printCanvas();
        String expectedCanvas = "----------------------\n|                    |\n|xxxxxx              |\n|                    |\n|                    |\n----------------------\n";

        assertEquals(actualCanvas, expectedCanvas);
    }


    @Test
    public void testDrawRectangle() throws Exception {

        Command drawRectangle = commandService.validateParameters(Command.DRAW_RECTANGLE, new String[]{"R", "14", "1", "18", "3"});

        drawingService.drawRectangle(drawRectangle, new String[]{"14", "1", "18", "3"});
        String actualCanvas = drawingService.printCanvas();

        String expectedCanvas = "----------------------\n|             xxxxx  |\n|             x   x  |\n|             xxxxx  |\n|                    |\n----------------------\n";
        assertEquals(actualCanvas, expectedCanvas);

    }


    @Test
    public void testRunCommand() throws Exception {

        Command drawRectangle = commandService.validateParameters(Command.DRAW_RECTANGLE, new String[]{"R", "14", "1", "18", "3"});

        drawingService.runCommand(drawRectangle);
        String actualCanvas = drawingService.printCanvas();

        String expectedCanvas = "----------------------\n|             xxxxx  |\n|             x   x  |\n|             xxxxx  |\n|                    |\n----------------------\n";
        assertEquals(actualCanvas, expectedCanvas);

    }
}
