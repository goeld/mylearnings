package com.cs.draw;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(JUnit4.class)
public class ApplicationTest {

    @Test
    public void runAllCommands() throws Exception {

        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource("file_input.txt").getFile());
        String filePath = file.getPath();

        Application application = new Application();

        try {
            Path path = Paths.get(filePath);
            List<String> inputCommands = Files.readAllLines(path);
            for (String inputCommand : inputCommands) {
                application.validateAndRunCommand(inputCommand);
            }
            String actualCanvas = application.drawingService.printCanvas();
            String expectedCanvas = "----------------------\n|oooooooooooooxxxxxoo|\n|xxxxxxooooooox   xoo|\n|     xoooooooxxxxxoo|\n|     xoooooooooooooo|\n----------------------\n";

            assertEquals(expectedCanvas, actualCanvas);

        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }

    }
}
