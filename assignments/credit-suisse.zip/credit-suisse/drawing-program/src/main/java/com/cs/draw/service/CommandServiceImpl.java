package com.cs.draw.service;

import com.cs.draw.exception.CommandException;
import com.cs.draw.domain.Command;

public class CommandServiceImpl implements CommandService {

    public static final String COMMAND_SEPARATOR = " ";

    @Override
    public Command getCommand(final String inputCommand) throws CommandException {

        String[] inputs = inputCommand.split(COMMAND_SEPARATOR);
        String command = inputs[0];
        return validateCommand(inputs);

    }

    public Command validateCommand(final String[] inputs) throws CommandException {
        final String inputCommand = inputs[0];
        final int noOfParams = inputs.length - 1;

        Command command = null;
        for (Command currentCommand : Command.values()) {
            if (currentCommand.getCommand().equalsIgnoreCase(inputCommand) && currentCommand.getNoOfParameters() == noOfParams) {
                command = currentCommand;
                break;
            }
        }

        if (command == null) {
            throw new CommandException("Command is invalid. Check command name and parameters");
        }

        validateParameters(command, inputs);

        return command;
    }

    public Command validateParameters(Command command, String[] inputs) throws CommandException {

        if (Command.QUIT == command) {
            return command;
        }

        int start = 1;
        int end = inputs.length;

        String[] params = new String[inputs.length - 1];
        if (Command.BUCKET_FILL == command) {
            end = inputs.length - 1;
            params[inputs.length - 2] = inputs[inputs.length - 1];
        } else if (Command.QUIT == command) {

        }
        for (int i = start; i < end; i++) {
            try {
                Integer.parseInt(inputs[i]);
                params[i - 1] = inputs[i];
            } catch (Exception e) {
                throw new CommandException("Invalid Command Parameters Specified");
            }
        }

        command.setInputs(params);
        return command;

    }

}
