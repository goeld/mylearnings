package com.cs.draw.service;

import com.cs.draw.exception.CommandException;
import com.cs.draw.domain.Command;

public interface CommandService {

    Command getCommand(String inputCommand) throws CommandException;
}
