package com.cs.draw.service;

import com.cs.draw.domain.Canvas;
import com.cs.draw.exception.DrawingException;
import com.cs.draw.domain.Command;

public interface DrawingService {

     Canvas runCommand(Command command) throws DrawingException;

     String printCanvas();
}
