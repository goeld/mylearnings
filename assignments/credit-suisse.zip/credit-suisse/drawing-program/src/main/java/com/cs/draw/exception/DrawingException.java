package com.cs.draw.exception;

public class DrawingException extends Exception {

    public DrawingException() {
    }

    public DrawingException(String message) {
        super(message);
    }

    public DrawingException(String message, Throwable cause) {
        super(message, cause);
    }

    public DrawingException(Throwable cause) {
        super(cause);
    }

    public DrawingException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
