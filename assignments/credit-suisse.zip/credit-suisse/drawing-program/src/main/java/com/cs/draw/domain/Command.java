package com.cs.draw.domain;

public enum Command {

    DRAW_CANVAS("C", 2),
    DRAW_LINE("L", 4),
    DRAW_RECTANGLE("R", 4),
    BUCKET_FILL("B", 3),
    QUIT("Q", 0);;

    private String command;
    private int noOfParameters;
    private String[] inputs;

    Command(String command, int noOfParameters) {
        this.command = command;
        this.noOfParameters = noOfParameters;
    }

    public String getCommand() {
        return command;
    }

    public int getNoOfParameters() {
        return noOfParameters;
    }


    public String[] getInputs() {
        return inputs;
    }

    public void setInputs(String[] inputs) {
        this.inputs = inputs;
    }

}
