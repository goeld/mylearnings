package com.cs.draw.domain;

public class Canvas {

    private char board[][];
    private int width;
    private int height;

    public Canvas(int width, int height) {
        this.width = width;
        this.height = height;
        int canvasWidth = this.width + 2;
        int canvasHeight = this.height + 2;

        initialiseBoard(canvasWidth, canvasHeight);
        drawBorderAxisX();
        drawBorderAxisY();

    }

    private void drawBorderAxisY() {
        for (int i = 1; i < this.height + 2 - 1; i++) {
            board[i][0] = '|';
            board[i][this.width + 1] = '|';
        }
    }

    private void drawBorderAxisX() {
        for (int i = 0; i < this.width + 2; i++) {
            board[0][i] = '-';
            board[this.height + 1][i] = '-';
        }
    }

    private void initialiseBoard(int canvasWidth, int canvasHeight) {
        board = new char[canvasHeight][];

        for (int i = 0; i < canvasHeight; i++) {
            board[i] = new char[canvasWidth];
        }

        for (int i = 0; i < canvasHeight; i++) {
            for (int j = 0; j < canvasWidth; j++) {
                board[i][j] = ' ';
            }
        }
    }

    public void setColor(int x, int y, char c) {
        board[y][x] = c;
    }

    public char getColor(int x, int y) {
        return board[y][x];
    }

    public char[][] getBoard() {
        return board;
    }

    public void setBoard(char[][] board) {
        this.board = board;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

}
