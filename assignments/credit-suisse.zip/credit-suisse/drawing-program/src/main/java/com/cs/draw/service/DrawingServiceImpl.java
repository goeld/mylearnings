package com.cs.draw.service;

import com.cs.draw.domain.Canvas;
import com.cs.draw.exception.DrawingException;
import com.cs.draw.domain.Command;

import java.util.ArrayList;
import java.util.List;

public class DrawingServiceImpl implements DrawingService {

    private Canvas canvas = null;

    @Override
    public Canvas runCommand(Command command) throws DrawingException {

        String[] params = command.getInputs();


        if (Command.DRAW_CANVAS == command) {
            Integer width = Integer.parseInt(params[0]);
            Integer height = Integer.parseInt(params[1]);
            canvas = new Canvas(width, height);
        } else if (Command.QUIT == command) {
            System.out.println("Ending program");
            System.exit(0);
        }

        if (canvas == null) {
            throw new DrawingException("Canvas is not initialised:");
        }


        if (Command.DRAW_LINE == command) {
            int x1 = Integer.parseInt(params[0]);
            int y1 = Integer.parseInt(params[1]);
            int x2 = Integer.parseInt(params[2]);
            int y2 = Integer.parseInt(params[3]);

            drawline(command, x1, y1, x2, y2);
        } else if (Command.DRAW_RECTANGLE == command) {
            drawRectangle(command, params);
        } else if (Command.BUCKET_FILL == command) {
            int x = Integer.parseInt(params[0]);
            int y = Integer.parseInt(params[1]);
            char color = params[2].charAt(0);

            // bucketFill(x,y,color);

            List<String> a = new ArrayList<>();
            a.add(x + "");
            a.add(y + "");
            a.add(color + "");

            bucketFill(x, y, color);

        }

        printCanvas();

        return canvas;


    }

    public void drawRectangle(Command command, String[] params) throws DrawingException {
        int x1 = Integer.parseInt(params[0]);
        int y1 = Integer.parseInt(params[1]);
        int x2 = Integer.parseInt(params[2]);
        int y2 = Integer.parseInt(params[3]);

        drawline(Command.DRAW_LINE, x1, y1, x1, y2);
        drawline(Command.DRAW_LINE, x1, y1, x2, y1);
        drawline(Command.DRAW_LINE, x1, y2, x2, y2);
        drawline(Command.DRAW_LINE, x2, y1, x2, y2);
    }

    public void drawline(Command command, int x1, int y1, int x2, int y2) throws DrawingException {
        if (Math.min(x1, x2) < 1
                || Math.max(x1, x2) > canvas.getWidth()
                || Math.min(y1, y2) < 1
                || Math.max(y1, y2) > canvas.getHeight()) {
            throw new DrawingException("Invalid input indices (-ve)");
        }

        if (x1 != x2 && y1 != y2) {
            throw new DrawingException("Horizontal Or Vertical lines are supported");
        }

        for (int y = Math.min(y1, y2); y <= Math.max(y1, y2); y++) {
            for (int x = Math.min(x1, x2); x <= Math.max(x1, x2); x++) {
                canvas.setColor(x, y, 'x');
            }
        }
    }

    @Override
    public String printCanvas() {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < canvas.getBoard().length; i++) {
            builder.append(canvas.getBoard()[i]);
            builder.append('\n');
        }
        System.out.println(builder.toString());

        return builder.toString();
    }

    private Canvas bucketFill(int x, int y, char color) throws DrawingException {

        if (canvas == null || canvas.getHeight() == 0
                || canvas.getWidth() == 0) {
            throw new DrawingException("Empty canvas provided");
        }

        if (color == 'x') {
            throw new DrawingException("Please choose another color to fill  instead of 'x'");
        }

        if (x < 1 || y < 1 || y > canvas.getHeight() || x > canvas.getWidth()) {
            throw new DrawingException("Co-orordinates out of canvas (" + x + "," + y + ")");
        }
        if (canvas.getColor(x, y) == 'x') {
            throw new DrawingException(" Co-ordinates are filled");
        }

        fill(x, y, color);

        return canvas;
    }

    private void fill(int x, int y, char color) {
        if (x == 0 || y == 0 || x > canvas.getWidth() || y > canvas.getHeight()
                || canvas.getColor(x, y) == 'x' || canvas.getColor(x, y) == color) {
            return;
        }
        canvas.setColor(x, y, color);

        fill(x + 1, y, color);
        fill(x, y + 1, color);
        fill(x - 1, y, color);
        fill(x, y - 1, color);
    }
}
