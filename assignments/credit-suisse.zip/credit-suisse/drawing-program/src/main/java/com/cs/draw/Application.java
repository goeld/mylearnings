package com.cs.draw;

import com.cs.draw.domain.Canvas;
import com.cs.draw.domain.Command;
import com.cs.draw.exception.CommandException;
import com.cs.draw.exception.DrawingException;
import com.cs.draw.service.CommandService;
import com.cs.draw.service.CommandServiceImpl;
import com.cs.draw.service.DrawingService;
import com.cs.draw.service.DrawingServiceImpl;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Scanner;

public class Application {

    public static DrawingService drawingService = new DrawingServiceImpl();

    public static void main(String[] args) {

        try {
            System.out.println("Input your command:\n");
            if (args == null || args.length == 0) {
                Scanner scanner = new Scanner(System.in);
                do {
                    String line = scanner.nextLine();
                    validateAndRunCommand(line);
                } while (scanner.hasNext());

            } else {

            }

        } catch (Exception ex) {
            System.out.println("Something went wrong, check the command once again");
            ex.printStackTrace();
        }
    }

    public static Canvas validateAndRunCommand(String inputCommand) throws DrawingException {
        CommandService commandService = new CommandServiceImpl();
        try {
            Command command = commandService.getCommand(inputCommand);
            return drawingService.runCommand(command);
        } catch (CommandException ex) {
            System.out.println(ex.getMessage());
            return validateAndRunCommand(inputCommand);
        }
    }

}
