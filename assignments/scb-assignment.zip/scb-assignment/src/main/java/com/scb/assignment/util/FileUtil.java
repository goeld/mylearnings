package com.scb.assignment.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class FileUtil {

    public List<String> readFile(String filePath) {
        try {
            FileInputStream fis = new FileInputStream((filePath));
            Scanner scanner = new Scanner((fis));
            List<String> lines = new ArrayList<>();
            while(scanner.hasNextLine()){
                lines.add(scanner.nextLine());
            }

            return lines;

        } catch (FileNotFoundException e) {
            e.printStackTrace();
            System.out.println("Error occured while reading file");
        }

        return null;

    }
}
