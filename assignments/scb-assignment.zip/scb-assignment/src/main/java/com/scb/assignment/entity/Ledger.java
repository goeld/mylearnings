package com.scb.assignment.entity;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDate;
import java.util.Comparator;

public class Ledger implements Comparator<Ledger> {
    private String transactionId;
    private String acccountId;
    private LocalDate postingDate;
    private Double amount;

    public Ledger(String transactionId, String acccountId, LocalDate postingDate, Double amount) {
        this.transactionId = transactionId;
        this.acccountId = acccountId;
        this.postingDate = postingDate;
        this.amount = amount;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getAcccountId() {
        return acccountId;
    }

    public void setAcccountId(String acccountId) {
        this.acccountId = acccountId;
    }

    public LocalDate getPostingDate() {
        return postingDate;
    }

    public void setPostingDate(LocalDate postingDate) {
        this.postingDate = postingDate;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    /*
     -1 - No Match
     0 - If Exact Match
     1 - Weak Match
     */
    @Override
    public int compare(Ledger first, Ledger second) {

        boolean accountIdMatches = first.getAcccountId().equals(second.getAcccountId());
        boolean postingDateMatches = first.getPostingDate().equals(second.getPostingDate());
        boolean amountMatches = first.getAmount().equals(second.getAmount());

        if (accountIdMatches) {
            if (postingDateMatches && amountMatches) {
                // All matches
                return 0;
            }

            boolean isPostingDateWithInThreshold = isPostingDateWeakMatch(first.getPostingDate(), second.getPostingDate());
            boolean isAmountWithInThreshold = isAmountWithInThreshold(first.getAmount(), second.getAmount());

            if (isPostingDateWithInThreshold && isAmountWithInThreshold) {
                return 1;
            }

            return -1;
        } else {
            return -1;
        }

    }

    private static DecimalFormat df2 = new DecimalFormat("#.##");

    private boolean isAmountWithInThreshold(Double first, Double second) {
        Double difference = first - second;
//        difference.setScale(2, RoundingMode.DOWN);
//        df2.setRoundingMode(RoundingMode.DOWN);
//        Double value = difference.doubleValue();

        BigDecimal bd = new BigDecimal(Double.toString(difference));
        bd = bd.setScale(2, RoundingMode.HALF_UP);
        Double finalD = bd.abs().doubleValue();


        return finalD <= 0.01;
    }

    private boolean isPostingDateWeakMatch(LocalDate first, LocalDate second) {

        long diffOfDates = Math.abs(Duration.between(first.atStartOfDay(), second.atStartOfDay()).toDays());

        int businessDaysToAdd = 0;
        if (first.getDayOfWeek() == DayOfWeek.FRIDAY) {
            businessDaysToAdd = 2;
        } else if (first.getDayOfWeek() == DayOfWeek.SUNDAY) {
            businessDaysToAdd = 1;
        }

        if (businessDaysToAdd > 0) {
            diffOfDates = diffOfDates - businessDaysToAdd;

            return diffOfDates <= 1;

        } else {
            return diffOfDates <= 1;
        }
    }

    @Override
    public boolean equals(Object obj) {

        Ledger another = (Ledger) obj;
        return
                this.acccountId != null && this.acccountId.equalsIgnoreCase(another.acccountId)
                        && this.postingDate != null && this.postingDate.atStartOfDay().equals(another.postingDate.atStartOfDay())
                        && this.amount != null && this.amount.equals(another.getAmount());

    }
}
