package com.scb.assignment.exceptions;

public class ReconcileException extends Exception{

    public ReconcileException(String message) {
        super(message);
    }
}
