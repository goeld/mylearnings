package com.scb.assignment;

import com.scb.assignment.constants.ReportConstants;

import java.util.Map;
import java.util.Set;

public class GenerateReport {
    public void generateReport(Map<String, Set<String>> report) {

        print(ReportConstants.KEY_EXACT_MATCH, report);
        print(ReportConstants.KEY_WEAK_MATCH, report);
        print(ReportConstants.KEY_X_BREAKS, report);
        print(ReportConstants.KEY_Y_BREAKS, report);
    }

    public void print(String key, Map<String, Set<String>> report) {
        Set<String> values = report.get(key);
        String value = values == null ? "" : String.join(",", values);

        System.out.println("# " + key);
        System.out.println(value);
        System.out.println();
    }
}
