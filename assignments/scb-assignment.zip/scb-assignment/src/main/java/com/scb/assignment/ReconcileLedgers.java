package com.scb.assignment;

import com.scb.assignment.entity.Ledger;
import com.scb.assignment.exceptions.ReconcileException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class ReconcileLedgers {

    private List<Ledger> first;
    private List<Ledger> second;

    private static final String KEY_EXACT_MATCH = "XY exact Match";
    private static final String KEY_WEAK_MATCH = "XY weak matches";
    private static final String KEY_X_BREAKS = "X breaks";
    private static final String KEY_Y_BREAKS = "Y breaks";

    public ReconcileLedgers(List<Ledger> first, List<Ledger> second) {
        this.first = first;
        this.second = second;
    }

    public Map<String, Set<String>> reconcile() throws ReconcileException {

        Map<String, Set<String>> reconcialtionMap = new HashMap<>();
        if ((first == null || first.size() <= 0)) {
            throw new ReconcileException("First Ledger is missing to reconcile");
        }

        if ((second == null || second.size() <= 0)) {
            throw new ReconcileException("Second Ledger is missing to reconcile");
        }


        Set<String> exactMatchTxnIds = findExactMatches(first, second);
        reconcialtionMap.put(KEY_EXACT_MATCH, exactMatchTxnIds);

        Set<String> weakMatchTxnIds = findWeakMatches(first, second);
        reconcialtionMap.put(KEY_WEAK_MATCH, weakMatchTxnIds);
        reconcialtionMap.put(KEY_X_BREAKS, first.stream().map( f -> f.getTransactionId()).collect(Collectors.toSet()) );
        reconcialtionMap.put(KEY_Y_BREAKS, second.stream().map( f -> f.getTransactionId()).collect(Collectors.toSet()) );




        return reconcialtionMap;

    }

    private Set<String> findWeakMatches(List<Ledger> first, List<Ledger> second) {
        List<Ledger> firstCopy = new ArrayList<>(first);


        Set<String> weakMatchingTxnIds = new HashSet<>();
        for (Ledger ledger : firstCopy) {
            List<Ledger> secondCopy = new ArrayList<>(second);
            Ledger weaklyMatchingLedger = null;
            Set<Ledger> matchingAccountLedgers = secondCopy.stream()
                    .filter(l -> l.getAcccountId().equals(ledger.getAcccountId()))
                    .collect(Collectors.toSet());

            for (Ledger match : matchingAccountLedgers) {
                if (match.compare(ledger, match) > 0) {
                    weaklyMatchingLedger = match;
                    break;
                }
            }
            if (weaklyMatchingLedger != null) {
                weakMatchingTxnIds.add(ledger.getTransactionId() + weaklyMatchingLedger.getTransactionId());
                first.remove(ledger);
                second.remove(weaklyMatchingLedger);
            }
        }



        return weakMatchingTxnIds;
    }

//    private Set<String> findXBreakIds(List<Ledger> first, List<Ledger> second) {
//
//        List<Ledger> firstCopy  = new ArrayList<>();
//        firstCopy.addAll(first);
//
//        List<Ledger> secondCopy  = new ArrayList<>();
//        secondCopy.addAll(second);
//        firstCopy.removeAll(secondCopy);
//
//        Set<String>
//    }

    private Set<String> findExactMatches(List<Ledger> first, final List<Ledger> second) {
        List<Ledger> firstCopy = new ArrayList<>(first);
        List<Ledger> secondCopy = new ArrayList<>(second);

        firstCopy.retainAll(secondCopy);

        Set<String> exactMatchTxnIds = new HashSet<>();
        for (Ledger ledger : firstCopy) {
            String x = ledger.getTransactionId();
            String y = secondCopy.stream()
                    .filter(item ->
                            item.getAcccountId().equals(ledger.getAcccountId())
                                    && item.getAmount().equals(ledger.getAmount())
                                    && item.getPostingDate().atStartOfDay().equals(ledger.getPostingDate().atStartOfDay())

                    )
                    .findFirst()
                    .get()
                    .getTransactionId();

            exactMatchTxnIds.add(x + y);
        }

        first.removeAll(firstCopy);
        second.removeAll(firstCopy);

        return exactMatchTxnIds;

    }

//    private void updateReconciliationMap(Map<String, Set<String>> reconcialtionMap, String transactionId, String key) {
//
//        if (reconcialtionMap.size() == 0) {
//            Set<String> values = new HashSet<>();
//            values.add(transactionId);
//            reconcialtionMap.put(key, values);
//            return;
//
//        }
//
//        for (Map.Entry<String, Set<String>> entry : reconcialtionMap.entrySet()) {
//            if (entry.getKey().equalsIgnoreCase(key)) {
//                Set<String> values = entry.getValue() == null ? new HashSet<>() : entry.getValue();
//                values.add(transactionId);
//                reconcialtionMap.put(key, values);
//                return;
//            }
//        }
//
//    }
//
//    public Set<Ledger> getLedgerByAccountId(String accountId, List<Ledger> ledgers) {
//        if (ledgers == null || ledgers.size() == 0 || accountId == null) {
//            return null;
//        }
//
//        Set<Ledger> outputLedgers = new HashSet<>();
//        for (Ledger ledger : ledgers) {
//            if (ledger.getAcccountId().equals(accountId)) {
//                outputLedgers.add(ledger);
//            }
//        }
//
//        return outputLedgers;
//    }
}
