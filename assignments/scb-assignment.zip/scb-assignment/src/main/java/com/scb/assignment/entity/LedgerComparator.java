package com.scb.assignment.entity;

import java.time.Duration;
import java.time.LocalDate;
import java.util.Comparator;

public class LedgerComparator /*implements Comparator<Ledger>*/ {

//    @Override
//    public int compare(Ledger first, Ledger second) {
//
//        boolean accountIdMatches = first.getAcccountId().equals(second.getAcccountId());
//        boolean postingDateMatches = first.getPostingDate().equals(second.getPostingDate());
//        boolean amountMatches = first.getAmount().equals(second.getAmount());
//
//        if (accountIdMatches) {
//            if (postingDateMatches && amountMatches) {
//                // All matches
//                return 0;
//            }
//
//            boolean isPostingDateWeakMatch = isPostingDateWeakMatch(first.getPostingDate(), second.getPostingDate());
//            boolean isAmountWekMatch = isAmountWeakMatch(first.getAmount(), second.getAmount());
//
//
//        } else {
//            return -1;
//        }
//
//        return 0;
//    }
//
//    private boolean isAmountWeakMatch(Double first, Double second) {
//        double percentageDiff = Math.abs((first - second) / first);
//        return percentageDiff <= 1;
//    }
//
//    private boolean isPostingDateWeakMatch(LocalDate first, LocalDate second) {
//
//        long diff = Math.abs(Duration.between(first, second).toDays());
//
//
//        return false;
//    }


}
