package com.scb.assignment.util;

import com.scb.assignment.entity.Ledger;
import com.scb.assignment.exceptions.InvalidInputException;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class LedgerParser {

    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy");

    public Ledger parse(String inputLine) throws InvalidInputException {
        if (inputLine == null || inputLine.length() <= 0) {
            return null;
        }

        String[] line = inputLine.split(";");

        if (line.length != 4) {
            throw new InvalidInputException("Invalid Input line : Line does not have 4 fields" + inputLine);
        }

        String transactionId = line[0] != null ? line[0].trim() : "";
        String accountId = line[1] != null ? line[1].trim() : "";
        LocalDate date = line[2] != null ? LocalDate.parse(line[2].trim(), formatter) : null;
        Double lineAmount = line[3] != null ? Double.parseDouble(line[3].trim()) : 0d;

        return new Ledger(transactionId, accountId, date, lineAmount);
    }

    public List<Ledger> parse(List<String> lines) throws InvalidInputException {
        if (lines == null) {
            throw new InvalidInputException("No lines to parse");
        }

        List<Ledger> ledgers = new ArrayList<>();
        lines.forEach(line -> {
            Ledger ledger = null;
            try {
                ledger = this.parse(line);
            } catch (InvalidInputException e) {
                e.printStackTrace();
            }
            ledgers.add(ledger);
        });

        return ledgers;
    }
}
