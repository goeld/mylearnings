package com.scb.assignment;

import com.scb.assignment.entity.Ledger;
import com.scb.assignment.exceptions.InvalidInputException;
import com.scb.assignment.exceptions.ReconcileException;
import com.scb.assignment.util.FileUtil;
import com.scb.assignment.util.LedgerParser;

import java.io.File;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Application {

    private List<String> loadFile(String filePath) {
        FileUtil fileUtil = new FileUtil();
        File file = new File(filePath);
        List<String> lines = fileUtil.readFile(file.getAbsolutePath());
//        lines.forEach(System.out::println);
        return lines;
    }

    private List<Ledger> parseToLedger(List<String> lines) throws InvalidInputException {
        LedgerParser parser = new LedgerParser();
        return parser.parse(lines);
    }

    private Map<String, Set<String>> reconcile(List<Ledger> ledgerX, List<Ledger> ledgerY) throws ReconcileException {
        ReconcileLedgers reconcileLedgers = new ReconcileLedgers(ledgerX, ledgerY);
        return reconcileLedgers.reconcile();
    }

    private void generateReport(Map<String, Set<String>> report){
        GenerateReport generator = new GenerateReport();
        generator.generateReport(report);

    }

    public static void main(String[] args) throws InvalidInputException, ReconcileException {
        Application application = new Application();

        // Load and parse First File
        List<String> xLines = application.loadFile("x.txt");
        List<Ledger> ledgerX = application.parseToLedger(xLines);

        // Load and Parse Second file
        List<String> yLines = application.loadFile("y.txt");
        List<Ledger> ledgerY = application.parseToLedger(yLines);

        // Reconcile the files
        Map<String, Set<String>> report = application.reconcile(ledgerX, ledgerY);

        //Print Report
        application.generateReport(report);


    }
}
