package com.scb.assignment.constants;

public interface ReportConstants {

    String KEY_EXACT_MATCH = "XY exact Match";
    String KEY_WEAK_MATCH = "XY weak matches";
    String KEY_X_BREAKS = "X breaks";
    String KEY_Y_BREAKS = "Y breaks";
}
