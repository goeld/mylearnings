package com.tremorvideo.vha.dao.mappers;

import java.util.List;

import org.springframework.stereotype.Component;

import com.tremorvideo.vha.dao.entity.VhaCampaign;

@Component
public interface OverviewCampaignMapper {
	List<VhaCampaign> getFirstResult(); 
}
