package com.tremorvideo.vha.services.overview;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tremorvideo.vha.dao.entity.VhaCampaign;
import com.tremorvideo.vha.dao.entity.VhaDeliverySummary;
import com.tremorvideo.vha.dao.mappers.DeliverySummaryMapper;
import com.tremorvideo.vha.dao.mappers.OverviewCampaignMapper;

@Service
public class OverviewCampaignServiceImpl implements OverviewCampaignService {

	@Autowired
	private transient OverviewCampaignMapper mapper;

	@Autowired
	private transient DeliverySummaryMapper dsMapper;

	@Override
	public List<VhaCampaign> getFirstResult() {
		return mapper.getFirstResult();
	}

	@Override
	public List<VhaDeliverySummary> getMaximumNoOfDeliverySummary(Long startId, Long nextId){
		long timeStart = System.currentTimeMillis();
		List<VhaDeliverySummary> results = dsMapper.getMaximumNoOfDeliverySummary(startId, nextId);
		long timeTaken = System.currentTimeMillis() - timeStart;
		System.out.println(" Time Taken to get data from DB  for delivery summary  OverviewCampaignServiceImpl.getMaximumNoOfDeliverySummary() ::" + timeTaken + "ms");
		return results;
	}

	
	@Override
	public List<VhaDeliverySummary> getAllDeliverySummary(Long startId, Long endId) {
		long timeStart = System.currentTimeMillis();
		List<VhaDeliverySummary> results = dsMapper.getAllDeliverySummary(startId, endId);
		long timeTaken = System.currentTimeMillis() - timeStart;
		return results;
	}

}
