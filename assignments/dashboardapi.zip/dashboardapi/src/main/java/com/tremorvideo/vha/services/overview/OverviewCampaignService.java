package com.tremorvideo.vha.services.overview;

import java.util.List;

import com.tremorvideo.vha.dao.entity.VhaCampaign;
import com.tremorvideo.vha.dao.entity.VhaDeliverySummary;

public interface OverviewCampaignService {

	List<VhaCampaign> getFirstResult();

	List<VhaDeliverySummary> getMaximumNoOfDeliverySummary(Long startId, Long nextId);

	List<VhaDeliverySummary> getAllDeliverySummary(Long startId, Long endId);
	
}
