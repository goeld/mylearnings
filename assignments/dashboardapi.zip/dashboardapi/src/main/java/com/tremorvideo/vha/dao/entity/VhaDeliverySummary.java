package com.tremorvideo.vha.dao.entity;

import java.util.Date;

public class VhaDeliverySummary {

	private Long id;
	private Long summaryId;
	private Long detailId;
	private Long campaignId;
	private Long advertiserId;
	private Date lastModifiedDate;
	private Long flightId;
	private Long siteId;
	private Long creativeId;
	private String metricTypeCd;
	private String metricTypeDesc;
	private Double detailValue;

	public Long getId() {
		return id;
	}

	public Long getSummaryId() {
		return summaryId;
	}

	public Long getDetailId() {
		return detailId;
	}

	public Long getCampaignId() {
		return campaignId;
	}

	public Long getAdvertiserId() {
		return advertiserId;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public Long getFlightId() {
		return flightId;
	}

	public Long getSiteId() {
		return siteId;
	}

	public Long getCreativeId() {
		return creativeId;
	}

	public String getMetricTypeCd() {
		return metricTypeCd;
	}

	public String getMetricTypeDesc() {
		return metricTypeDesc;
	}

	public Double getDetailValue() {
		return detailValue;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setSummaryId(Long summaryId) {
		this.summaryId = summaryId;
	}

	public void setDetailId(Long detailId) {
		this.detailId = detailId;
	}

	public void setCampaignId(Long campaignId) {
		this.campaignId = campaignId;
	}

	public void setAdvertiserId(Long advertiserId) {
		this.advertiserId = advertiserId;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public void setFlightId(Long flightId) {
		this.flightId = flightId;
	}

	public void setSiteId(Long siteId) {
		this.siteId = siteId;
	}

	public void setCreativeId(Long creativeId) {
		this.creativeId = creativeId;
	}

	public void setMetricTypeCd(String metricTypeCd) {
		this.metricTypeCd = metricTypeCd;
	}

	public void setMetricTypeDesc(String metricTypeDesc) {
		this.metricTypeDesc = metricTypeDesc;
	}

	public void setDetailValue(Double detailValue) {
		this.detailValue = detailValue;
	}

}
