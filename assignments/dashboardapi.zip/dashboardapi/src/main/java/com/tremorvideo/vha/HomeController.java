package com.tremorvideo.vha;

import static org.elasticsearch.common.xcontent.XContentFactory.jsonBuilder;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.MediaType;

import org.codehaus.jackson.map.ObjectMapper;
import org.elasticsearch.action.bulk.BulkRequestBuilder;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.client.Client;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.ImmutableSettings;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJacksonHttpMessageConverter;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;

import com.tremorvideo.vha.dao.entity.VhaCampaign;
import com.tremorvideo.vha.dao.entity.VhaDeliverySummary;
import com.tremorvideo.vha.services.overview.OverviewCampaignService;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	private static final String SERVER_URI = "http://localhost:9200/overviewcampaigns/vhaCampaign";
	private static Client client;

	static {
		Settings settings = ImmutableSettings.settingsBuilder().put("cluster.name", "elasticsearch").build();
		InetSocketTransportAddress address = new InetSocketTransportAddress("192.168.1.11", 9200);
		InetSocketTransportAddress address2 = new InetSocketTransportAddress("192.168.1.11", 9300);
		TransportClient tClient = new TransportClient(settings);
		tClient.addTransportAddress(address);
		tClient.addTransportAddress(address2);
		client = tClient;

	}

	@Autowired
	private OverviewCampaignService service;

	/**
	 * Simply selects the home view to render by returning its name.
	 * 
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = { "/getIndexById" }, method = { RequestMethod.GET }, produces = MediaType.APPLICATION_JSON)
	public Object indexAll(Model model) throws Exception {
		List<VhaCampaign> data = service.getFirstResult();

		RestTemplate rt = new RestTemplate();
		List<HttpMessageConverter<?>> messageConverters = new ArrayList<HttpMessageConverter<?>>();
		messageConverters.add(new FormHttpMessageConverter());
		messageConverters.add(new StringHttpMessageConverter());
		messageConverters.add(new MappingJacksonHttpMessageConverter());
		rt.setMessageConverters(messageConverters);

		System.out.println("Total no of records from db :: " + data.size());
		int i = 0;
		for (VhaCampaign d : data) {
			indexData(d, rt);
			i++;
		}

		System.out.println("Total no of records indexed :: " + i);
		return rt.getForEntity(SERVER_URI + "/63", VhaCampaign.class);
	}

	private void indexData(VhaCampaign data, RestTemplate rt) throws Exception {
		String json = null;
		try {
			ObjectMapper m = new ObjectMapper();
			json = m.writeValueAsString(data);
			rt.put(SERVER_URI + "/" + data.getId(), json);
		} catch (Exception e) {
		}
	}

	@RequestMapping(value = { "/indexAllDeiverySummary" }, method = { RequestMethod.GET }, produces = MediaType.APPLICATION_JSON)
	public String indexDeliverySummary(ModelMap model) throws Exception {
		long beginTime = System.currentTimeMillis();
		System.out.println("Welcome to elastic search demo, The time now is ::" + beginTime + " ms");

		Long startId = 9691270971L;
		Long endId = 18172318803L;
		Long nextId;
		// int iterationNo = 0;
		System.out.println("Start indexing from id  ::" + startId);
		System.out.println("Indexing will finish at id  ::" + endId);
		while (startId < endId) {
			nextId = startId + 10000;
			List<VhaDeliverySummary> data = this.service.getAllDeliverySummary(startId, nextId);
			// System.out.println("Total no of records from db for iteration[" + iterationNo + "] ::" + data.size());
			if (data.size() > 0) {
				// long timeDiff = System.currentTimeMillis();
				// Bulk update
				// long timeStart = System.currentTimeMillis();
				// Client client = node.client();
				BulkRequestBuilder bulkRequest = client.prepareBulk();
				for (VhaDeliverySummary d : data) {
					bulkRequest.add(client.prepareIndex("overviewcampaigns", "deliverySummaryBulk", d.getId().toString()).setSource(
							jsonBuilder().startObject().field("advertiserId", d.getAdvertiserId()).field("campaignId", d.getCampaignId())
									.field("creativeId", d.getCreativeId()).field("summaryId", d.getSummaryId()).field("detailId", d.getDetailId())
									.field("lastModifiedDate", d.getLastModifiedDate()).field("flightId", d.getFlightId())
									.field("siteId", d.getSiteId()).field("metricTypeCd", d.getMetricTypeCd())
									.field("metricTypeDesc", d.getMetricTypeDesc()).field("detailValue", d.getDetailValue()).endObject()));
				}

				BulkResponse bulkResponse = bulkRequest.execute().actionGet();
				if (bulkResponse.hasFailures()) {
					System.out.println("There was some failure");
				}
				// timeDiff = System.currentTimeMillis() - timeStart;
				// System.out.println("Total time taken to index Delivery summary " + iterationNo + "th iteration :: " + timeDiff + "ms");
			}
			startId = nextId + 1;
			// iterationNo++;
		}

		long endTime = System.currentTimeMillis();
		System.out.println("Processing finished at ::" + endTime);
		System.out.println("Total time taken ::" + (endTime - beginTime));
		model.put("message", (endTime - beginTime));
		return "home";
	}

	@RequestMapping(value = { "/indexMaximumNoOfDeliverySummary" }, method = { RequestMethod.GET }, produces = MediaType.APPLICATION_JSON)
	public String indexMaximumNoOfDeliverySummary(ModelMap model) throws Exception {
		long beginTime = System.currentTimeMillis();
		System.out.println("Welcome to elastic search demo, The time now is ::" + beginTime + " ms");
		Long startId = 0L;
		Long nextId;
		int iterationNo = 0;
		boolean hasMoreRecords = true;
		while (hasMoreRecords) {

			System.out.println(" Iteration no[" + iterationNo + "]");

			nextId = startId + 10000;
			List<VhaDeliverySummary> data = this.service.getMaximumNoOfDeliverySummary(startId, nextId);
			if (data.size() <= 0) {
				System.out.println("No more records are found in DB exiting  :: ");
				hasMoreRecords = false;
				break;
			}

			System.out.println("Total no of records from db :: " + data.size());

			// Bulk update
			long timeStart = System.currentTimeMillis();
			// Client client = node.client();
			BulkRequestBuilder bulkRequest = client.prepareBulk();
			for (VhaDeliverySummary d : data) {
				bulkRequest.add(client.prepareIndex("overviewcampaigns", "maxDeliverySummaries2", d.getId().toString()).setSource(
						jsonBuilder().startObject().field("advertiserId", d.getAdvertiserId()).field("campaignId", d.getCampaignId())
								.field("creativeId", d.getCreativeId()).field("summaryId", d.getSummaryId()).field("detailId", d.getDetailId())
								.field("lastModifiedDate", d.getLastModifiedDate()).field("flightId", d.getFlightId()).field("siteId", d.getSiteId())
								.field("metricTypeCd", d.getMetricTypeCd()).field("metricTypeDesc", d.getMetricTypeDesc())
								.field("detailValue", d.getDetailValue()).endObject()));
			}

			BulkResponse bulkResponse = bulkRequest.execute().actionGet();

			if (bulkResponse.hasFailures()) {
				System.out.println("There was some failure");
			}

			long timeDiff = System.currentTimeMillis() - timeStart;
			System.out.println("Time taken to index Delivery summary data for iteration[" + iterationNo + "] :: " + timeDiff + " ms, i.e., "
					+ timeDiff / 1000  + " seconds");

			startId = nextId + 1;
			iterationNo++;
		}

		
		System.out.println("All iterations has been completed successfully");
		long endTime = System.currentTimeMillis();
		System.out.println("The now is ::" + endTime);
		double totalTimeToFinish = (endTime - beginTime);
		System.out.println("Time taken to retreive data and index is :" + totalTimeToFinish);

		String message = "The data has been indexed succssfully in " + totalTimeToFinish + " : ms";
		model.put("message", message);
		return "home";
	}

	public static void main(String[] args) {

		Integer a = new Integer(1);
		Integer b = new Integer(1);

		System.out.println("a==b? " + (a == b));
		System.out.println("a.equals(b)? " + a.equals(b));
		System.out.println("a==1? " + (a == 1));
		System.out.println("1==b? " + (1 == b));

		Integer c = Integer.valueOf(1);
		Integer d = Integer.valueOf(1);

		System.out.println("c==d? " + (c == d));

	}
//select count(totals) from ( select t2.id from signal_by_campaign_site_summary as t1 inner join signal_by_campaign_site_summary_detail as t2 on t2.summary_id = t1.id inner join metric_type_mapping as t3 on t3.metric_type_cd = t2.metric_type_cd inner join signal_type_mapping as t4 on t4.signal_type_cd = t1.signal_type_cd inner join campaign c on t1.flight_id = c.id and c.discriminator_type = 'FLIGHT' where t4.signal_type_desc in ('All','PlayerViewability') group by t1.flight_id, t1.site_id, t3.metric_type_desc ) as in_ner_table;
}
