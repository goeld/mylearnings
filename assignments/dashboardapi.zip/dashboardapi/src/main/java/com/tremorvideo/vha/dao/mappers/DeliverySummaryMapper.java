package com.tremorvideo.vha.dao.mappers;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import com.tremorvideo.vha.dao.entity.VhaDeliverySummary;

@Component
public interface DeliverySummaryMapper {

	List<VhaDeliverySummary> getMaximumNoOfDeliverySummary(@Param("startId") Long startId, @Param("endId") Long endId);
	
	List<VhaDeliverySummary> getAllDeliverySummary(@Param("startId") Long startId, @Param("endId") Long endId);
}
