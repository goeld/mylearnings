package com.tremorvideo.vha.dao.entity;

import java.util.Date;

public class VhaCampaign {

	private Long id;
	private Long campaignId;
	private Long advertiserId;
	private Long networkId;
	private String name;
	private String alias;
	private String advertiserName;
	private String advertiserAlias;
	private Date startDate;
	private Date endDate;
	private String discriminatorType;
	private Integer funnelTypeCode;

	public Long getId() {
		return id;
	}

	public Long getCampaignId() {
		return campaignId;
	}

	public Long getAdvertiserId() {
		return advertiserId;
	}

	public Long getNetworkId() {
		return networkId;
	}

	public String getName() {
		return name;
	}

	public String getAlias() {
		return alias;
	}

	public String getAdvertiserName() {
		return advertiserName;
	}

	public String getAdvertiserAlias() {
		return advertiserAlias;
	}

	public Date getStartDate() {
		return startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public String getDiscriminatorType() {
		return discriminatorType;
	}

	public Integer getFunnelTypeCode() {
		return funnelTypeCode;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setCampaignId(Long campaignId) {
		this.campaignId = campaignId;
	}

	public void setAdvertiserId(Long advertiserId) {
		this.advertiserId = advertiserId;
	}

	public void setNetworkId(Long networkId) {
		this.networkId = networkId;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setAlias(String alias) {
		this.alias = alias;
	}

	public void setAdvertiserName(String advertiserName) {
		this.advertiserName = advertiserName;
	}

	public void setAdvertiserAlias(String advertiserAlias) {
		this.advertiserAlias = advertiserAlias;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public void setDiscriminatorType(String discriminatorType) {
		this.discriminatorType = discriminatorType;
	}

	public void setFunnelTypeCode(Integer funnelTypeCode) {
		this.funnelTypeCode = funnelTypeCode;
	}

}