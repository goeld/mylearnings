from setuptools import setup, find_packages

setup(
    name='crea',
    extras_require=dict(tests=["pytest"]),

    version='0.0.1',
    author='Goel, Deepak',
    author_email='goel_deepakin@yahoo.com',
    packages=find_packages(where='src'),
    package_dir={"": "src"},
    scripts="",
    description='App for finding shortest distance between nodes',
    long_description=open('README.md').read(),
)
