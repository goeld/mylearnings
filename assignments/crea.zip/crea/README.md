###Steps to run the program

* Getting app code ready
  * Unzip the file
    * Download the zip file from email.
    * unzip at your <work_dir>
  * (OR) download from git hub to your <work_dir> 
* Change the directory to src directory
    ```shell
      % cd <work_dir>/crea/src
    ```
* Running the program
    ```shell
    $ python3 main.py --file=routes.csv
    ```
