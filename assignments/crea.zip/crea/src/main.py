from file.file_util import FileUtil
from paths.paths import PathUtil
from routes.routes import RouteMap


class Main:
    def __init__(self):
        file_util = FileUtil()
        file_name = file_util.get_file_name()
        routes = file_util.load_routes(file_name)
        route_map = RouteMap(routes)
        routes_dict_for_node = route_map.prepare_routes_map()
        route_distance_map = route_map.route_distance_map
        self.path_util = PathUtil(route_map)

    def find_shortest_path(self, start_station, end_station):
        return self.path_util.find_shortest_path(start_station, end_station)

    def calcuate_distance(self, shortest_path):
        return self.path_util.calcuate_distance(shortest_path)


if __name__ == '__main__':
    main = Main()

    start_station = input("\nWhat station are you getting on the train?:")
    end_station = input("\nWhat station are you getting off the train?:")
    shortest_path = main.find_shortest_path(start_station, end_station)
    if shortest_path is not None:
        no_of_stops = len(shortest_path) - 2
        distance = main.calcuate_distance(shortest_path)
        print(
            f"\nYour trip from {start_station} to {end_station} includes {no_of_stops} stops, and will take  {distance} minutes")
    else:
        print(f"No routes from {start_station} to {end_station}")
