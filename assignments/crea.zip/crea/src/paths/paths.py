from routes.routes import Route, RouteMap


class PathUtil:

    def __init__(self, route_map):
        self.route_distance_dict = route_map.route_distance_map
        vertices_set = set()
        for k, v in self.route_distance_dict.items():
            vertices_set.update(list(k))

        self.vertices_set = vertices_set
        self.all_paths_from_each_node = route_map.build_source_routes_paths(route_map.route_distance_map)


    def find_shortest_path(self, source, destination):
        self.validate_start_destination(source, destination)
        visited_path = []
        queue = [[source]]

        while queue:
            current_path = queue.pop(0)
            node = current_path[-1]

            if node not in visited_path:
                # next_nodes = self.all_paths_from_each_node[node]
                for next_node in self.all_paths_from_each_node[node]:
                    new_path = list(current_path)
                    new_path.append(next_node)
                    queue.append(new_path)
                    if next_node == destination:
                        return new_path
                visited_path.append(node)
        return None

    def calcuate_distance(self, nodes: []):
        if nodes is None:
            raise Exception("No path are defined")

        length = len(nodes)
        total_distance = 0
        for i in range(length):
            if i + 1 < length:
                route = nodes[i] + nodes[(i + 1)]
                total_distance += self.route_distance_dict[route]
        return total_distance

    def validate_start_destination(self, end, start):
        if start is None or end is None:
            raise Exception("Invalid start or destination")
        if start not in self.vertices_set or end not in self.vertices_set:
            raise Exception("Either Start or destination does not exist")
