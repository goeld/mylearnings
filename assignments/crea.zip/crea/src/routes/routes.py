from collections import defaultdict

class Route:

    def __init__(self, start, end, distance):
        if start is None or end is None or start.upper() == end.upper():
            raise Exception("Invalid Route - Either route end are not defined or start is same as destination")

        if distance <= 0:
            raise Exception("Invalid Route - Distance must be +ve")

        self.start = start.upper()
        self.end = end.upper()
        self.distance = distance

    def get_key(self) -> str:
        return self.start + self.end

    def get_route_distance(self) -> int:
        return self.distance

class RouteMap:

    def __init__(self, routes):
        self.routes = routes
        self.routes_dict_for_node = dict()
        self.route_distance_map = {}

    def prepare_routes_map(self):
        route_distnce_map = {}
        for route in self.routes:
            # print(f"start :{route.start}, end: {route.end}, distance: {route.distance}")
            existing_routes = self.routes_dict_for_node.get(route.start)
            # key = route.get_key()
            route_distnce_map[route.get_key()] = route.distance
            if existing_routes is None:
                existing_routes = []
                existing_routes.append(route)
            else:
                if self.is_route_existing_for_node(route.start, route.end):
                    print("\n\nDuplicate Route \n\n")
                else:
                    existing_routes.append(Route(route.start, route.end, route.distance))

            self.routes_dict_for_node[route.start] = existing_routes

        self.route_distance_map = route_distnce_map



    def build_source_routes_paths(self, route_distance_dict: {}):

        all_paths_from_each_node = defaultdict(list)
        routes = list(route_distance_dict.keys())
        for route in routes:
            start, end = route[0], route[1]
            all_paths_from_each_node[start].append(end)
        return all_paths_from_each_node

    def is_route_existing_for_node(self, start, end):
        routes = self.routes_dict_for_node.get(start)
        for route in routes:
            if route.start == start and route.end == end:
                return True

        return False
