import pytest
from routes.routes import Route, RouteMap


def test_route_initialisation():
    with pytest.raises(Exception):
        Route(None, "B", 5)
    with pytest.raises(Exception):
        Route("A", None, 5)
    with pytest.raises(Exception):
        Route("A", "A", 5)
    with pytest.raises(Exception):
        Route("A", "B", 0)
    with pytest.raises(Exception):
        Route("A", "B", -1)
    with pytest.raises(Exception):
        Route(None, None, -1)

    Route("A", "B", 1)
    route = Route("a", "b", 1)
    assert route.start == "A"
    assert route.start != "a"
    assert route.end == "B"
    assert route.end != "b"
    assert route.distance == 1


def test_route_get_key():
    route = Route("A", "B", 5)
    assert route.get_key() == "AB"


def test_prepare_routes_map():
    # Data preparation
    routes = get_testing_routes()
    # routes = []
    routes.append(Route("A", "C", 10))
    routes.append(Route("A", "E", 10))

    # Execution
    route_map = RouteMap(routes)
    route_map.prepare_routes_map()
    route_dict = route_map.routes_dict_for_node

    # Assertions
    assert len(route_dict) == 8
    assert len(route_dict.get("A")) == 4
    assert len(route_dict.get("C")) == 1
    assert len(route_dict.get("E")) == 2
    assert len(route_dict.get("F")) == 1
    assert len(route_dict.get("G")) == 1
    assert len(route_dict.get("H")) == 1
    assert len(route_dict.get("I")) == 1
    assert len(route_dict.get("K")) == 1

    route_mappings = route_map.route_distance_map
    assert len(route_mappings) == 12
    assert route_mappings["AB"] == 5
    assert route_mappings["AD"] == 15
    assert route_mappings["CD"] == 7


def test_is_route_existing():
    routes = []
    routes.append(Route("A", "C", 10))
    routes.append(Route("A", "E", 10))
    # Execution
    route_map = RouteMap(routes)
    route_map.prepare_routes_map()
    assert route_map.is_route_existing_for_node("A", "C") == True
    assert route_map.is_route_existing_for_node("A", "E") == True
    assert route_map.is_route_existing_for_node("A", "J") == False


def test_get_route_distance():
    route_ac = Route("A", "C", 10)
    assert route_ac.get_route_distance() == 10


def get_testing_routes() -> []:
    routes = []
    routes.append(Route("A", "B", 5))
    routes.append(Route("A", "D", 15))
    routes.append(Route("C", "D", 7))
    routes.append(Route("E", "F", 5))
    routes.append(Route("F", "G", 5))
    routes.append(Route("G", "H", 10))
    routes.append(Route("H", "I", 10))
    routes.append(Route("I", "J", 5))
    routes.append(Route("K", "J", 20))
    routes.append(Route("E", "J", 20))
    return routes
