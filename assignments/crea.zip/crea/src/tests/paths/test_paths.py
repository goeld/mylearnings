import pytest
from paths.paths import PathUtil
from routes.routes import Route, RouteMap


def test_validate_start_destination():
    routes = []
    routes.append(Route("A", "C", 10))
    routes.append(Route("A", "E", 20))
    route_map = RouteMap(routes)
    route_map.prepare_routes_map()
    path_util = PathUtil(route_map)

    # Test valid path does not throw exception
    path_util.validate_start_destination("A", "C")
    path_util.validate_start_destination("A", "E")

    with pytest.raises(Exception):
        path_util.validate_start_destination(None, "C")
    with pytest.raises(Exception):
        path_util.validate_start_destination("C", None)
    with pytest.raises(Exception):
        path_util.validate_start_destination("A", "N")
    with pytest.raises(Exception):
        path_util.validate_start_destination("X", "C")


def test_find_shortest_path():
    routes = prepate_routes()
    route_map = RouteMap(routes)
    route_map.prepare_routes_map()
    path_util = PathUtil(route_map)

    assert ["A", "B", "C"] == path_util.find_shortest_path("A", "C")
    assert ["A", "D"] == path_util.find_shortest_path("A", "D")
    assert ["E", "J"] == path_util.find_shortest_path("E", "J")
    assert ["A", "E", "J"] == path_util.find_shortest_path("A", "J")
    assert ["A", "E"] == path_util.find_shortest_path("A", "E")


def prepate_routes():
    routes = []
    routes.append(Route("A", "B", 1))
    routes.append(Route("A", "D", 1))
    routes.append(Route("A", "E", 1))
    routes.append(Route("B", "C", 2))
    routes.append(Route("C", "D", 3))
    routes.append(Route("D", "E", 4))
    routes.append(Route("E", "F", 5))
    routes.append(Route("E", "J", 5))
    routes.append(Route("F", "G", 6))
    routes.append(Route("G", "H", 7))
    routes.append(Route("H", "I", 8))
    routes.append(Route("I", "J", 9))
    routes.append(Route("K", "J", 10))
    return routes


def prepare_route_map():
    routes = []
    routes.append(Route("A", "C", 10))
    routes.append(Route("A", "E", 20))
    route_map = RouteMap(routes)
    route_map = route_map.prepare_routes_map()

    return route_map


def prepare_test_data():
    routes = []
    routes.append(Route("A", "C", 10))
    routes.append(Route("A", "E", 20))
    route_map = RouteMap(routes)
    route_map.prepare_routes_map()
    route_distance_dict = route_map.route_distance_map
    routes_from_node_dict = route_map.routes_dict_for_node

    return (route_distance_dict, routes_from_node_dict)
