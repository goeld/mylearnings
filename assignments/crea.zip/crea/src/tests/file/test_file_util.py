import sys

import pytest
from file.file_util import FileUtil


def test_has_file_parameter():
    sys.argv = ["--file=routes_length.csv"]

    file_util = FileUtil()
    file_name = file_util.get_file_name()
    print(f"FILE NAME: {file_name}")
    assert file_name == "routes_length.csv"


def test_has_no_file_parameter():
    sys.argv = []
    file_util = FileUtil()
    with pytest.raises(Exception):
        file_util.get_file_name()


def test_has_no_file_parameter():
    file_util = FileUtil()
    file_name = "routes_empty.csv"
    with pytest.raises(Exception):
        routes = file_util.load_routes(file_name)


def test_load_routes():
    file_util = FileUtil()
    file_name = "routes_length.csv"
    routes = file_util.load_routes(file_name)
    assert len(routes) == 10
