import sys

from routes.routes import Route


class FileUtil:

    def get_file_name(__self__) -> str:
        has_file_param = False
        for i, arg in enumerate(sys.argv):
            if arg.startswith("--file"):
                has_file_param = True
                file_nme = arg.split("=")[1]

        if not has_file_param or file_nme.strip() == "":
            raise Exception("No Routes file found")

        return file_nme

    def load_routes(self, file_path) -> []:
        routes = []
        with open(file_path, "r") as reader:
            lines = reader.read().splitlines()

        if lines is None or lines == []:
            raise Exception("Route list is empty")

        for line in lines:
            input = line.split(",")
            route = Route(input[0], input[1], int(input[2]))
            routes.append(route)
        return routes
